const db = require("../config/db");

const Appointment = {
  // Get all appointments
  
};
module.exports = Appointment;